<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newChickenCounts = $_POST['chickenCounts'];
    $chickenID = 1;

    // Update the chicken counts in the database
    $stmt = $conn->prepare("UPDATE chicken SET counts = ? WHERE CID = ?");
    $stmt->bind_param("ii", $newChickenCounts, $chickenID); // Adjust the binding parameters based on your table structure

    if ($stmt->execute()) {
        header("Location: index.php?message=chicken_counts_updated");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
