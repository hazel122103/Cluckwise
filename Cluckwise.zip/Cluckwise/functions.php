<?php
function getTotalCounts($conn) {
    $sql = "SELECT SUM(counts) AS total_counts FROM chicken";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['total_counts'];
    } else {
        return 0;
    }
}
