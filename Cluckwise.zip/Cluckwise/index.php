<?php
session_start();

// Check if the user is logged in, if not then redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Include connection and functions file
include 'connection.php';
include 'functions.php';

// Fetch pond data
$sql = "SELECT FID, Date, Time, Notes, ID FROM feeding";
$result = $conn->query($sql);

// Check for success message
$welcomeMessage = isset($_SESSION['message']) ? $_SESSION['message'] : '';
unset($_SESSION['message']);

// Get total counts
$TotalCounts = getTotalCounts($conn);

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - Cluckwise</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
     
    <nav class="sb-topnav navbar navbar-expand navbar-light bg-light">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="index.html">Cluckwise</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            
        </form>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">

                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i><?php echo htmlspecialchars($_SESSION['username']); ?></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="index.html">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            TotalCounts
                        </a>

                       <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#addEntryModal">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        New Feeding
                    </a>


                    </div>
                </div>
             
            </nav>
        </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                                           <!-- Check for success messages -->
                        <div class="container mt-3">
                               <!-- Check for success messages -->
                                <div class="container mt-3">
                                    <?php
                                    if (isset($_GET['message'])) {
                                        if ($_GET['message'] == 'update_success') {
                                            echo '<div class="alert alert-success text-center">Record updated successfully!</div>';
                                        } elseif ($_GET['message'] == 'delete_success') {
                                            echo '<div class="alert alert-success text-center">Record deleted successfully!</div>';
                                        } elseif ($_GET['message'] == 'feeding_updated') {
                                            echo '<div class="alert alert-success text-center">Feeding record updated successfully!</div>';
                                        } elseif ($_GET['message'] == 'chicken_counts_updated') {
                                            echo '<div class="alert alert-success text-center">Chicken counts updated successfully!</div>';
                                        } elseif ($_GET['message'] == 'login_success') {
                                            echo '<div class="alert alert-success text-center">Welcome, you have successfully logged in!</div>';
                                        }
                                    }
                                    ?>
                                </div>
                        </div>
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                        <div class="row">
                            <div class=" col-xl-3 col-md-6 col-xs-12">
                                <div class="card bg-primary text-white mb-4">
                                    <div class="card-body">Total chickens</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <h3><?php echo number_format($TotalCounts); ?></h3>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#updateChickenCountsModal" onclick="setCurrentCounts(<?php echo $TotalCounts; ?>)">
                                            <i class="fas fa-edit text-white"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8 col-md-6 col-xs-12">
                               <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area me-1"></i>
                                        Boiler Daily Harvest
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="30"></canvas></div>
                                    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                                </div>
                        </div>

                        </div>

                        <div class="row">

                        

                        <div class="row">
                            

                            <div class="col-xl-12">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-table me-1"></i>
                                        Feeding Monitoring
                                    </div>
                                    <div class="card-body">
                                        <table id="datatablesSimple">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Notes</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Notes</th>
                                                    <th>Action</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php
                                                if ($result->num_rows > 0) {
                                                    while($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<td>" . date("M d, Y", strtotime(htmlspecialchars($row["Date"]))) . "</td>";
                                                        echo "<td>" . date("h:i:s A", strtotime(htmlspecialchars($row["Time"]))) . "</td>";
                                                        echo "<td>" . htmlspecialchars($row["Notes"]) . "</td>";
                                                        echo "<td class='text-center'><a href='#' class='edit-feeding' data-id='" . $row["FID"] . "' data-date='" . $row["Date"] . "' data-time='" . $row["Time"] . "' data-notes='" . $row["Notes"] . "'><i class='fas fa-edit'></i></a></td>";
                                                        echo "</tr>";
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='4'>No records found</td></tr>";
                                                }
                                                ?>
                                            </tbody>
                                        </table>


                                    </div>
                                </div>
                            </div>

                           

                        </div>
                        
                    </div>
                </main>
            </div>
        </div>

<!-- Modal -->
<div class="modal fade" id="addEntryModal" tabindex="-1" aria-labelledby="addEntryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addEntryModalLabel">Add New Feeding</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addEntryForm" action="add_feeding.php" method="POST">
                    <div class="mb-3">
                        <label for="date" class="form-label">Date</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="time" class="form-label">Time</label>
                        <input type="time" class="form-control" id="time" name="time" required>
                    </div>
                    <div class="mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3" required></textarea>
                    </div>
                    <input type="hidden" id="user_id" name="user_id" value="<?php echo $_SESSION['ID']; ?>">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Feeding Details Modal -->
<div class="modal fade" id="feedingDetailsModal" tabindex="-1" aria-labelledby="feedingDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="feedingDetailsModalLabel">Feeding Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editFeedingForm" action="update_feeding.php" method="POST">
                    <input type="hidden" id="feedingID" name="fid">
                    <div class="mb-3">
                        <label for="feedingDate" class="form-label">Date</label>
                        <input type="date" class="form-control" id="feedingDate" name="date" required>
                    </div>
                    <div class="mb-3">
                        <label for="feedingTime" class="form-label">Time</label>
                        <input type="time" class="form-control" id="feedingTime" name="time" required>
                    </div>
                    <div class="mb-3">
                        <label for="feedingNotes" class="form-label">Notes</label>
                        <textarea class="form-control" id="feedingNotes" name="notes" rows="3" required></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <button type="button" class="btn btn-danger ms-auto" id="deleteFeedingButton">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="updateChickenCountsModal" tabindex="-1" aria-labelledby="updateChickenCountsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateChickenCountsModalLabel">Update Chicken Counts</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="updateChickenCountsForm" action="update_chicken_counts.php" method="POST">
                    <div class="mb-3">
                        <label for="chickenCounts" class="form-label">New Chicken Counts</label>
                        <input type="number" class="form-control" id="chickenCounts" name="chickenCounts" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var editButtons = document.querySelectorAll('.edit-feeding');
    editButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            var feedingID = this.getAttribute('data-id');
            var feedingDate = this.getAttribute('data-date');
            var feedingTime = this.getAttribute('data-time');
            var feedingNotes = this.getAttribute('data-notes');
            
            document.getElementById('feedingID').value = feedingID;
            document.getElementById('feedingDate').value = feedingDate;
            document.getElementById('feedingTime').value = feedingTime;
            document.getElementById('feedingNotes').value = feedingNotes;
            
            var deleteButton = document.getElementById('deleteFeedingButton');
            deleteButton.setAttribute('data-id', feedingID);
            
            var feedingModal = new bootstrap.Modal(document.getElementById('feedingDetailsModal'));
            feedingModal.show();
        });
    });
    
    document.getElementById('deleteFeedingButton').addEventListener('click', function() {
        var feedingID = this.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this feeding record?')) {
            window.location.href = 'delete_feeding.php?fid=' + feedingID;
        }
    });
});
</script>

<script>
    function setCurrentCounts(currentCounts) {
        document.getElementById('chickenCounts').value = currentCounts;
    }
</script>




        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>


        


    </body>
</html>
