<?php
include 'connection.php';

if (isset($_GET['fid'])) {
    $fid = $_GET['fid'];

    // Prepare and bind
    $stmt = $conn->prepare("DELETE FROM feeding WHERE FID = ?");
    $stmt->bind_param("i", $fid);

    if ($stmt->execute()) {
        // Successfully deleted
        header("location: index.php?message=feeding_deleted");
    } else {
        // Error occurred
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>
