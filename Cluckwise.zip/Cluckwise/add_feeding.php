<?php
include 'connection.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date'];
    $time = $_POST['time'];
    $notes = $_POST['notes'];
    $user_id = $_POST['user_id'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO feeding (Date, Time, Notes, ID) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $date, $time, $notes, $user_id);

    if ($stmt->execute()) {
        // Successfully inserted
        header("location: index.php?message=feeding_added");
    } else {
        // Error occurred
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>
