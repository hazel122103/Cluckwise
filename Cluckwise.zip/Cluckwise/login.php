<?php
include 'connection.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the input password using MD5
    $hashed_password_input = md5($password);

    // Prepare and bind
    $stmt = $conn->prepare("SELECT ID, Password FROM users WHERE Username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($ID, $hashed_password);
        $stmt->fetch();
        if ($hashed_password_input === $hashed_password) {
            // Password is correct, start a new session
            $_SESSION['loggedin'] = true;
            $_SESSION['ID'] = $ID;
            $_SESSION['username'] = $username;
            $_SESSION['welcome'] = "Welcome, you have successfully logged in!";

            header("Location: index.php?message=login_success"); // Redirect to the dashboard page with message
            exit();
        } else {
            $login_err = "Invalid password.";
        }
    } else {
        $login_err = "No account found with that username.";
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Dashboard - Cluckwise</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/custom.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="bg-primary bg-cover">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="row no-gutters">
                                    <div class="col-md-4 text-center p-4">
                                        <div class="avatar-frame">
                                            <img src="assets/img/avatar.png" alt="Chicken" class="rounded-circle mb-3" style="width: 150px; height: 150px;">
                                                                                        <h3 class="font-weight-light my-4 text-center">Cluckwise</h3>

                                        </div>

                                        
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <?php 
                                            if (!empty($login_err)) {
                                                echo '<div class="alert alert-danger">' . $login_err . '</div>';
                                            } elseif (isset($_GET['message']) && $_GET['message'] == 'loggedout') {
                                                echo '<div class="alert alert-info">You have been logged out successfully.</div>';
                                            }
                                            ?>

                                            <h3 class="font-weight-light my-4 text-center">Login</h3>
                                            <form action="login.php" method="post">
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" id="username" type="text" name="username" required />
                                                    <label for="username">Username</label>
                                                </div>
                                                <div class="form-floating mb-3">
                                                    <input class="form-control" id="inputPassword" type="password" name="password" placeholder="Password" required />
                                                    <label for="inputPassword">Password</label>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mt-4 mb-0">
                                                    <button type="submit" class="btn btn-danger text-center">Login</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
