<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fid = $_POST['fid'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $notes = $_POST['notes'];

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE feeding SET Date = ?, Time = ?, Notes = ? WHERE FID = ?");
    $stmt->bind_param("sssi", $date, $time, $notes, $fid);

    if ($stmt->execute()) {
        // Successfully updated
        header("location: index.php?message=feeding_updated");
    } else {
        // Error occurred
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>
